# WorkTrace Project Brain

## Product Vision

WorkTrace is a local-first macOS work memory system. It observes the user's active work rhythm, compresses noisy computer activity into meaningful human work history, and later may use a small amount of AI analysis over compressed work history.

WorkTrace is not a time tracker, employee monitoring tool, productivity scoring application, or judgment system.

## Core Philosophy

1. Compress, don't collect.
2. Local before cloud.
3. Reflect, don't judge.
4. Invisible first: minimize manual input.
5. Compress first. Understand later. AI comes last.
6. AI should analyze compressed Memory, Pattern, Story, Timeline, Mission, and Session data later, never raw Samples.

## Permanent Data Pipeline

This order is permanent and must not be changed:

Sample

Activity Block

Session

Mission

Timeline

Story

Pattern

Memory

Reflection

Each layer contains less data than the previous layer and more meaning than the previous layer.

## Compression Philosophy

The project is building a language for work memory. Use this vocabulary consistently:

- Sample: a lightweight raw observation of the frontmost app.
- Activity Block: continuous work inside one application.
- Session: a meaningful work period.
- Mission: the first semantic layer above Session, grouping nearby related Sessions.
- Timeline: today's Missions represented chronologically.
- Story: one work day's compressed work history.
- Pattern: repeated deterministic work structures discovered across compressed history.
- Memory: local structured deterministic facts built from compressed layers.
- Reflection: future AI-only interpretation of Memory, Patterns, Stories, Timeline, Missions, and Sessions.

Phase 8 implements the deterministic Memory layer:

- Consecutive Samples from the same application become one Activity Block.
- Activity Blocks separated by no more than the idle threshold can merge into one Session.
- Sessions separated by less than the Mission idle threshold can merge into one Mission.
- Today's Missions become a chronological Timeline.
- Today's Missions become one rule-based Story.
- Repeated app sequences across Missions become Patterns.
- Story, Timeline, Patterns, and Missions become a local MemoryBook.

No AI, NLP, ML, interpretation, prediction, scoring, ranking, or behavioral judgment is implemented.

Phase 8.1 is a dashboard simplification and macOS polish phase only. It does not add a new data layer or change the permanent pipeline.

Phase 8.2 adjusts dashboard disclosure defaults so important sections are expandable but initially visible. It does not add a new data layer or change the permanent pipeline.

Phase 8.3 is a dashboard detail cleanup phase. It reduces Memory and Story repetition, moves Data Status lower, and keeps Diagnostics available but quieter. It does not add a new data layer or change the permanent pipeline.

Phase 9 introduces MemoryBook Foundation as a product-facing presentation layer. MemoryBook is not AI, not Reflection, not persistence, and not a pipeline change. It presents today's compressed work like a notebook using existing MemoryBook, Story, Timeline, Patterns, and Missions.

## Current Architecture

- `WorkTraceApp.swift`: app entry point, shared state ownership, dashboard scene, menu bar commands.
- `Models/ActivityEvent.swift`: Sample model.
- `Models/AppUsageSummary.swift`: current v0.1 daily app usage aggregate.
- `Models/ActivityBlock.swift`: continuous work inside one application.
- `Models/Session.swift`: meaningful work period with deterministic metadata: dominant app, app count, switch count, and confidence.
- `Models/Mission.swift`: first semantic layer above Session with derived duration, dominant app, app count, session count, and confidence.
- `Models/Timeline.swift`: computed daily Timeline and Timeline item models.
- `Models/Story.swift`: daily work story backed by Missions with deterministic summary fields and highlights.
- `Models/Pattern.swift`: repeated deterministic work behavior with sequence, frequency, average start time, average duration, confidence, and last seen.
- `Models/MemoryItem.swift`: typed deterministic memory fact.
- `Models/MemoryBook.swift`: one day of MemoryItems.
- `Tracking/ActivityTracker.swift`: frontmost app sampler and start/pause timer control.
- `Storage/ActivityStore.swift`: local JSON persistence, raw Sample retention cleanup, existing incremental daily summary updates.
- `Analytics/ActivityAggregator.swift`: existing top-app summary builder.
- `Compression/CompressionEngine.swift`: permanent home of compression transformations.
- `Compression/SessionDetector.swift`: rule-based Activity Block to Session detection.
- `Compression/StoryGenerator.swift`: deterministic local Mission to Story generation.
- `Mission/MissionDetector.swift`: rule-based Session to Mission detection.
- `Timeline/TimelineBuilder.swift`: deterministic Mission to Timeline transformation.
- `Pattern/PatternEngine.swift`: deterministic Pattern discovery over compressed Stories, Missions, or Sessions.
- `Memory/MemoryBuilder.swift`: deterministic compressed layer to MemoryBook transformation.
- `State/CompressionState.swift`: observes stored Samples and publishes the current Activity Blocks, Sessions, Missions, Timeline, Story, Patterns, and MemoryBook.
- `Views/DashboardView.swift`: simplified main dashboard layout and compact controls.
- `Views/Components/DashboardComponents.swift`: reusable display-only dashboard components.
- `Views/MemoryBook/MemoryBookView.swift`: product-facing notebook presentation of today's compressed work.
- `Views/MemoryBook/MemoryBookHeader.swift`: notebook heading and date context.
- `Views/MemoryBook/MemoryTimelineSection.swift`: notebook-style presentation of today's Timeline.
- `Views/MemoryBook/MemoryStorySection.swift`: notebook-style presentation of Story highlights.
- `Views/MemoryBook/MemoryPatternSection.swift`: notebook-style presentation of deterministic Patterns.
- `Views/MemoryBook/MemoryFactsSection.swift`: notebook-style presentation of Memory facts.
- `Views/CompressionView.swift`: Sample to Activity Block to Session to Mission to Timeline to Story status.
- `Views/MissionSummaryView.swift`: current Mission count and latest Mission summary.
- `Views/TodayTimelineView.swift`: default-expanded chronological view of today's Missions.
- `Views/StoryView.swift`: compact daily Story highlights.
- `Views/PatternSummaryView.swift`: compact Pattern count, top frequency, and last updated status.
- `Views/MemoryView.swift`: compact Memory item count, titles, and details.
- `Views/TopAppsView.swift`: ranked app usage list.
- `Views/TimelineView.swift`: recent Sample timeline.
- `Views/DataStatusView.swift`: local data and privacy status.

Responsibilities:

- CompressionEngine does not know about SwiftUI.
- Views do not perform compression.
- Tracking does not perform aggregation.
- Storage remains responsible for persistence and retention.

## Current Version

Phase 9 - MemoryBook Foundation.

The app is a macOS SwiftUI menu bar app with a simplified dashboard, compact start/pause controls, local frontmost-app sampling, local JSON persistence, raw Sample retention, current top-app summaries, a product-facing MemoryBook notebook view, quieter diagnostics, deterministic Session detection, deterministic Mission detection, computed Timeline generation, deterministic local Story generation, deterministic Pattern discovery, and deterministic Memory generation.

## Current Phase

Phase 9 - MemoryBook Foundation.

## Privacy Decisions

- No AI calls.
- No network requests.
- No file content reading.
- No clipboard reading.
- No screenshot capture.
- No browser history access.
- No notification permissions.
- No reminders.
- Window title is optional and only attempted through safe Accessibility APIs. If permission is unavailable or the call fails, WorkTrace records app name and bundle identifier only.

## Storage Policy

- v0.1 stores lightweight raw Samples in local JSON under the user's Application Support directory.
- Raw Samples are retained for only the latest 3 days.
- Cleanup runs on app launch and after each new Sample.
- Today's top-app summary is updated incrementally after each Sample to avoid unnecessary full recomputation during normal tracking.

## AI Rules

- AI is not implemented.
- AI must not receive raw Samples.
- Future AI reflection may only operate on MemoryBook, Pattern, Story, Timeline, Mission, and Session.
- AI must be optional and local-first where feasible.
- AI output should support reflection, not judgment or scoring.

## Completed Roadmap

- Phase 1: Local Sampling MVP - completed.
- Phase 2: Compression Framework - completed.
- Phase 3: Session Intelligence - completed.
- Phase 4: Mission Engine - completed.
- Phase 4.1: Dashboard Stability and Layout Fix - completed.
- Phase 5: Local Story Generation - completed.
- Phase 6: Pattern Engine Foundation - completed.
- Phase 7: Timeline Engine - completed.
- Phase 8: Memory Engine Foundation - completed.
- Phase 8.1: Dashboard Simplification and macOS Polish - completed.
- Phase 8.2: Default Expanded Dashboard Sections - completed.
- Phase 8.3: Dashboard Detail Cleanup - completed.

## Current Roadmap

- Phase 9: MemoryBook Foundation - current.

## Future Roadmap

- Phase 10: Reflection Context - future.
- Phase 11: Optional AI Reflection - future.

## Features Intentionally Not Implemented Yet

- AI Reflection.
- Reflection Context.
- Cloud sync.
- Browser-specific analysis.
- File content analysis.
- Screenshot or clipboard capture.
- Reminders and notifications.

## Development Journal

### Phase 1

Created the macOS SwiftUI menu bar skeleton, dashboard, tracking controls, frontmost app sampling, local JSON persistence, 3-day raw Sample retention, incremental top-app summary, clear data action, and privacy status.

### Phase 2

Added the permanent pipeline vocabulary and architecture:

Sample -> Activity Block -> Session -> Mission -> Timeline -> Story -> Pattern -> Memory -> Reflection.

Created `ActivityBlock`, `Session`, `Story`, `CompressionEngine`, `CompressionState`, and dashboard compression status. Compression remains intentionally simple and deterministic. No AI, networking, reminders, notifications, clipboard reads, screenshots, browser history, or file content reads were added.

### Phase 3

Implemented deterministic Session Intelligence.

Phase 3 introduced `SessionDetector` so Activity Block to Session logic has a clear permanent home outside SwiftUI, tracking, and storage. `CompressionEngine` still owns the pipeline shape, but delegates Session detection to `SessionDetector`.

Session metadata now includes dominant app, app count, switch count, and confidence. This matters because future Story generation and optional AI Reflection need compact, meaningful Session-level signals instead of raw Samples. The metadata is deterministic and local-only.

AI is still not implemented because the compression layers are not yet mature enough. WorkTrace must first produce reliable Sessions, Missions, Timelines, Stories, Patterns, and Memory, then future AI can reflect on those compressed layers only.

This phase prepares future AI Reflection by making Session data richer while preserving privacy boundaries: no raw Samples are prepared for AI, no network calls are added, and no content capture is introduced.

### Phase 4

Implemented the Mission Engine foundation.

Phase 4 introduced `Mission` and `MissionDetector`. Mission is the first semantic layer above Session. It groups nearby Sessions into a larger work unit using a deterministic 15-minute idle-gap rule.

`Story` now stores Missions and can still expose Sessions derived from those Missions. This keeps the app compatible with existing Session-level UI while moving the pipeline toward Mission-backed daily Stories.

Mission metadata matters because future Story generation and optional AI Reflection need compact, meaningful work arcs. A Mission can describe a larger unit of intent than a single Session while still avoiding raw Sample exposure.

AI is still not implemented. WorkTrace is still building local compression layers first. Future AI may only consume compressed Memory, Pattern, Story, Timeline, Mission, or Session data, never raw Samples.

No networking, reminders, notifications, clipboard reads, screenshots, browser history, file content reading, or AI calls were added.

### Phase 4.1

Improved dashboard stability without adding a new product layer.

Phase 4.1 focused on dashboard scrollability, layout stability, and defensive UI formatting. The dashboard now scrolls vertically, uses safer compact section layouts, and avoids assuming that Sessions, Missions, or Stories exist.

Added display-only formatting helpers for dashboard durations and confidence values. Durations never show negative values, active durations under one minute display as `<1m`, and confidence displays as a percentage or `—` when unavailable.

This phase did not change the permanent pipeline, compression logic, Session detection, Mission detection, tracking behavior, storage behavior, or privacy boundaries.

No networking, reminders, notifications, clipboard reads, screenshots, browser history, file content reading, or AI calls were added.

### Phase 5

Implemented deterministic local Story generation from Missions.

Phase 5 introduced `StoryGenerator` so Mission to Story logic has a clear permanent home outside SwiftUI and outside the pipeline coordinator. `CompressionEngine` still owns the pipeline order, but delegates Story wording and highlights to `StoryGenerator`.

`Story` now stores useful daily summary fields: total Mission count, total Session count, total duration, dominant app, generated summary, and highlights. This matters because future Pattern Expansion and optional AI Reflection need compact daily meaning, not raw Samples.

The dashboard now includes a compact Today's Story section showing the generated summary and up to four deterministic highlights.

AI is still not implemented. Story generation is rule-based, local-only, and generated from Missions only. Future AI may consume MemoryBook, Patterns, Stories, Timeline, and Missions, never raw Samples.

No networking, reminders, notifications, clipboard reads, screenshots, browser history, file content reading, or AI calls were added.

### Phase 6

Implemented the deterministic Pattern Engine foundation.

Phase 6 introduced `Pattern` and `PatternEngine`. Pattern is the final deterministic layer before future AI Reflection:

Sample -> Activity Block -> Session -> Mission -> Timeline -> Story -> Pattern -> Memory -> Reflection.

The first implemented Pattern is Repeated App Sequence. `PatternEngine` discovers repeated Mission app sequences and stores only deterministic facts: sequence, frequency, average start time, average duration, confidence, and last seen.

Pattern metadata matters because future Reflection should operate on stable repeated structures rather than raw Samples. Patterns do not interpret behavior, infer intent, infer emotion, predict future actions, classify activities, or score productivity.

The dashboard now includes a compact Pattern Summary with Patterns Found, Top Pattern Frequency, and Last Updated.

AI is still not implemented. Pattern discovery is local-only and rule-based. Future AI may consume MemoryBook, Patterns, Stories, Timeline, and Missions, never raw Samples.

No interpretation, prediction, productivity scoring, networking, reminders, notifications, clipboard reads, screenshots, browser history, file content reading, or AI calls were added.

### Phase 7

Implemented the deterministic Timeline Engine.

Phase 7 introduced `Timeline`, `TimelineItem`, and `TimelineBuilder`. Timeline is a computed chronological representation of today's Missions:

Sample -> Activity Block -> Session -> Mission -> Timeline -> Story -> Pattern -> Memory -> Reflection.

Timeline exists only in memory as computed state. It is built from existing Missions, sorted chronologically, and protected against overlapping Timeline items by clamping each item start to the previous item end.

The dashboard now includes a default-collapsed Today Timeline section. When expanded, it shows a lightweight time and dominant-app list for today's Missions.

Timeline matters because future AI analysis should consume compressed chronological work structure instead of raw Samples or low-level statistics. Timeline provides order and context without storing or exposing raw activity.

No tracking frequency, storage, Session detection, Mission detection, Story generation, or Pattern detection behavior changed.

No AI, networking, notifications, reminders, clipboard reads, screenshots, browser history, file content reading, or raw content capture were added.

### Phase 8

Implemented the deterministic Memory Engine foundation.

Phase 8 introduced `MemoryItem`, `MemoryBook`, and `MemoryBuilder`. Memory is a local structured summary layer before future Reflection:

Sample -> Activity Block -> Session -> Mission -> Timeline -> Story -> Pattern -> Memory -> Reflection.

Memory is not AI. It turns compressed outputs into short deterministic facts: daily summary, dominant app, long Mission, repeated Pattern, and Timeline shape.

Memory exists so future AI receives compact structured facts instead of raw Samples, noisy statistics, or uncompressed activity. Future AI must consume MemoryBook, Story, Timeline, Patterns, and Missions only, never raw Samples.

MemoryBook is computed state only and is not persisted in Phase 8.

No AI, networking, reminders, notifications, clipboard reads, screenshots, browser history, file content reading, or raw content capture were added.

### Phase 8.1

Simplified the dashboard and improved macOS polish without adding a product layer.

Phase 8.1 made Today Summary, Memory, Today Timeline, and Data Status the primary visible sections. Memory is visually prioritized as the main product output, while Story and technical details remain available through collapsed sections.

Added compact toolbar-style controls in the header for start/pause tracking, clearing local data, and a disabled Settings placeholder. No floating window was added.

Compression, Pattern Summary, Mission Summary, Top Apps, Recent Timeline, and latest Session details are still present, but they are less visually dominant by default. This keeps the dashboard calm while preserving diagnostic information useful during development.

No compression, tracking, storage, Memory, Pattern, Timeline, Story, Mission, or Session logic was changed.

No AI, networking, reminders, notifications, clipboard reads, screenshots, browser history, file content reading, floating windows, or raw content capture were added.

### Phase 8.2

Adjusted dashboard disclosure defaults while preserving the Phase 8.1 macOS polish.

Today Timeline, Story, and Technical Details now open expanded by default so important compressed context is initially visible. Users can still collapse or expand these sections manually.

To avoid clutter, Today Timeline, Top Apps, and Recent Timeline show up to five visible rows. Additional-row placeholder text keeps the expanded dashboard compact without removing the underlying data or changing storage.

No compression, tracking, storage, Memory, Pattern, Timeline, Story, Mission, or Session logic was changed.

No AI, networking, reminders, notifications, clipboard reads, screenshots, browser history, file content reading, floating windows, or raw content capture were added.

### Phase 8.3

Cleaned up dashboard details without adding a product layer.

Memory remains the primary daily output. Story no longer repeats the generated daily summary when Memory already carries that fact; Story now focuses on deterministic highlights.

The dashboard order now follows the product hierarchy more clearly: Header, Today Summary, Memory, Story, Today Timeline, Diagnostics, and Data Status. Data Status appears lower as a privacy/footer section.

Technical Details was renamed to Diagnostics. Diagnostics remains expanded by default but is visually quieter, with smaller section titles and compact row limits preserved.

No compression, tracking, storage, Memory, Pattern, Timeline, Story, Mission, or Session logic was changed.

No AI, networking, reminders, notifications, clipboard reads, screenshots, browser history, file content reading, floating windows, or raw content capture were added.

### Phase 9

Introduced MemoryBook Foundation as the first product-facing presentation of compressed work history.

MemoryBook is not a new compression layer, not persistence, not Reflection, and not AI. It is a notebook-style presentation that consumes existing computed state: MemoryBook, Story, Timeline, Patterns, and Missions.

The dashboard now embeds `MemoryBookView` instead of expanding with more standalone product sections. This keeps the dashboard feature-complete for this stage and shifts future work toward product value rather than additional dashboard surface area.

`MemoryBookView` is split into reusable presentation components: header, timeline, story, patterns, and memory facts. These components display computed state only and do not perform detection, compression, storage, networking, or AI calls.

No compression, tracking, storage, Memory, Pattern, Timeline, Story, Mission, or Session logic was changed.

No AI, Reflection, networking, reminders, notifications, clipboard reads, screenshots, browser history, file content reading, persistence, floating windows, or raw content capture were added.

## Review Notes

Architecture Review:
- `PatternEngine` is separate from UI, storage, tracking, and `CompressionEngine`.
- `TimelineBuilder` is separate from UI, storage, tracking, and `MissionDetector`.
- `MemoryBuilder` is separate from UI, storage, tracking, and raw Samples.
- `StoryGenerator` remains separate from UI and `CompressionEngine`.
- `MemoryBookView` is a presentation layer only and does not change the pipeline.

UI Review:
- MemoryBook is the primary product-facing dashboard output.
- The dashboard should not keep growing with more standalone product sections at this stage.
- Diagnostics are available, expanded by default, and visually quieter.
- Data Status appears lower as a privacy/footer section.

Performance Review:
- Patterns are generated from compressed Missions, Stories, or Sessions only.
- Timeline is generated from existing Missions only and never rescans raw Samples.
- Memory is generated from Story, Timeline, Patterns, and Missions only.
- Story is generated from Missions only.

AI Readiness Review:
- Future AI can consume MemoryBook, Patterns, Stories, Timeline, and Missions only.
